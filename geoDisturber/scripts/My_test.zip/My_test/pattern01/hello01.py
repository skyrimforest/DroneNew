from hello00 import say_hello
import time

if __name__ == '__main__':
    while True:
        time.sleep(1)
        say_hello()

